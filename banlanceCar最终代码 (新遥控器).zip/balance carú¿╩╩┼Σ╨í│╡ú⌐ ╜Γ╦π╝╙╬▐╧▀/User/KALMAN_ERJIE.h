#ifndef  __KALMAN_ERJIE_H
#define  __KALMAN_ERJIE_H

#include "stm32f10x.h"
//DSP��
#include "arm_math.h"

extern float const sine[200];
extern float const sinespeed[200];
extern float KalmanData2[2];

void Kalman_filter_x(float J_Accel,float W_Gyro,float Q0,float Q3,float R0,float R3);



#endif

