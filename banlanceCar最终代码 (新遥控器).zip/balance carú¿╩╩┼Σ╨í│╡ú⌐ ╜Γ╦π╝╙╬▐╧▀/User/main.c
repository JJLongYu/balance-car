#include "stm32f10x.h"   // �൱��51��Ƭ���е�  #include <reg51.h>
#include "usart.h"
#include "i2c_moni.h"
#include "mpu6050.h"
#include "nvic.h"
#include "mpu6050_i2cmoni.h"
#include "systick.h"
#include "dmp_exti.h"
#include "oled.h"
#include "BMP.h"
#include "MotorControl.h"
#include "encoder.h"
#include "ADC.h"
#include "timej.h"
#include "2401.h"  
#include "control.h"

#include "Attitude_angle.h"
#include "KALMAN_ERJIE.h"


#define MAX_TX  		0x10  //�ﵽ����ʹ����ж�
#define TX_OK   		0x20  //TX��������ж�
#define RX_OK   		0x40  //���յ������ж�

//extern float pit,rol,yaw;							//��̬��
extern int Encoder_Left,Encoder_Right;
extern float Velocity_Left,Velocity_Right;	//�����ٶ�(mm/s)
extern uint16_t ADC_ConvertedValue;
extern float wendu;                            //MPU6050���¶�
extern float Pitch,Roll,Yaw;
extern uint32_t mode,Kp,Ki;
extern float Kd,xx,yy;
extern uint16_t zz;
extern int Motor_Left,Motor_Right; 
extern int Encoder_Left,Encoder_Right; 
extern float dianya2;
extern double roll_two,pitch_two;
extern float Balance_Kp,Balance_Ki,Balance_Kd,Velocity_Kp;

u8 Flag_Stop=1,Flag_Show=0;                 //���ֹͣ��־λ����ʾ��־λ  Ĭ��ֹͣ ��ʾ��
u8 delay_flag = 1, delay_count = 0;		//�ⲿ����,���������ṩ50ms�ľ�׼��ʱ
int jiaodu;
char jiaodu1,jiaodu2,jiaodu3,jiaodu4;
char Motor_Right1,Motor_Right2,Motor_Right3,Motor_Right4;
int Velocity_Left_real;
char Velocity_Left1,Velocity_Left2,Velocity_Left3,Velocity_Left4;
u8 go_flag;
u8 jiajian_flag,mode_flag;
u8 RxBuf[21]={0};//������2401���յ�������
u8 TxBuf[21]={0};
u8 ID;
u8 sta,qidong=1;
u8 jia_flag,jian_flag,qiehuan_flag,init_flag;
u8 jia,jian,mode1=1;
int PPP=Velocity_Kp_Preset,III=Balance_Ki_Preset;
float DDD=Balance_Kd_Preset;
int Balance_Kp_real;
u8 Balance_Kp1,Balance_Kp2,Balance_Kp3,Balance_Kp4;
int Balance_Ki_real;
u8 Balance_Ki1,Balance_Ki2;
int Balance_Kd_real;
u8 Balance_Kd1,Balance_Kd2;
u8 king_flag;
void KEY_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
}

int main(void)

{ 

	SysTick_init();
	NRF24L01_GPIO_Init();
//	u8 MotorLeft[]={"MotorLeft:"};
//	u8 P[]={"Pit:"};
//	u8 MotorRight[]={"MotorRight:"};
	u8 Kpp[]={"Kp:"};
	u8 Kii[]={"Ki:"};
	u8 Kdd[]={"Kd:"};
//	char wendu1[5];
//	char Vdianya[5];
	// ���������ʱ��ϵͳ��ʱ���Ѿ������ó�72M��
	USART_Config();
	printf("usart is ready\r\n");
	
	MOTOR_GPIO_Config(); 
		
  ADCx_Init();
	
	IIC_Init();				//IIC��ʼ��
	
	MPU6050_MoniI2c_Config();  //MPU6050��ʼ��
	
//	DMP_Init();
	
	KEY_Init();
	
  ange_TIMt_PWM_init();
	ange_TIMj_init();
	GPIO_OLED_InitConfig(); 
	OLED_Clear();

	OLED_ShowString(7,0,Kpp,8,1);
	OLED_ShowString(7,16,Kii,8,1);
	OLED_ShowString(7,32,Kdd,8,1);
	OLED_Refresh_Gram();	
	
	Encoder_Init_TIM8();
	Encoder_Init_TIM4();	
	
	//���ж����ȼ�����
	NVIC_PriorityConfig();
	
	//����DMP�ж�����źŵ�EXTI��ʼ��
	DMP_EXTIConfig();	
	while(1)
		{   
/********************�շ�ģʽ*******************************/
       if(king_flag==0)
			 {
					/*****************���ݷ���*******************/
					if(delay_count<50)
					{  
						SPI_RW_Reg(NRF24L01_WRITE_REG+STATUS,0xff);
						jiaodu = (int)(roll_two*100);
						jiaodu1 = (jiaodu >>24)&0x000000ff;jiaodu2 = (jiaodu>>16)&0x000000ff;jiaodu3 = (jiaodu>>8)&0x000000ff;jiaodu4 = (jiaodu)&0x000000ff;
						TxBuf[0]=jiaodu1; TxBuf[1]=jiaodu2;TxBuf[2]=jiaodu3;TxBuf[3]=jiaodu4;

						Motor_Right1 = (Motor_Right >>24)&0x000000ff;Motor_Right2 = (Motor_Right>>16)&0x000000ff;Motor_Right3 = (Motor_Right>>8)&0x000000ff;Motor_Right4 = (Motor_Right)&0x000000ff;
						TxBuf[4]=Motor_Right1; TxBuf[5]=Motor_Right2;TxBuf[6]=Motor_Right3;TxBuf[7]=Motor_Right4;

						Velocity_Left_real= (int)(Velocity_Left*100);
						Velocity_Left1 = (Velocity_Left_real >>24)&0x000000ff;Velocity_Left2 = (Velocity_Left_real>>16)&0x000000ff;Velocity_Left3 = (Velocity_Left_real>>8)&0x000000ff;Velocity_Left4 = (Velocity_Left_real)&0x000000ff;
						TxBuf[8]=Velocity_Left1; TxBuf[9]=Velocity_Left2;TxBuf[10]=Velocity_Left3;TxBuf[11]=Velocity_Left4;
						
						Balance_Kp_real= (int)(Velocity_Kp*100);
						Balance_Kp1 = (Balance_Kp_real >>24)&0x000000ff;Balance_Kp2 = (Balance_Kp_real>>16)&0x000000ff;Balance_Kp3 = (Balance_Kp_real>>8)&0x000000ff;Balance_Kp4 = (Balance_Kp_real)&0x000000ff;
						TxBuf[12]=Balance_Kp1; TxBuf[13]=Balance_Kp2;TxBuf[14]=Balance_Kp3;TxBuf[15]=Balance_Kp4;
						
						Balance_Ki_real= (int)(Balance_Ki);
						Balance_Ki1 = (Balance_Ki_real >>8)&0x000000ff;Balance_Ki2 = (Balance_Ki_real)&0x000000ff;
						TxBuf[16]=Balance_Ki1; TxBuf[17]=Balance_Ki2;
						
						Balance_Kd_real= (int)(Balance_Kd*100);
						Balance_Kd1 = (Balance_Kd_real >>8)&0x000000ff;Balance_Kd2 = (Balance_Kd_real)&0x000000ff;
						TxBuf[18]=Balance_Kd1; TxBuf[19]=Balance_Kd2;
						
						TxBuf[20]=mode1;
						
						NRF24L01_TX_Mode();
						delay_us(1000);
						nRF24L01_TxPacket(TxBuf);
						sta=SPI_Read(STATUS);
				/***************����ָ�����***********************/
						if(mode_flag==1)
						{
							mode1++;
							if(mode1>4)
							{
								mode1=1;
							}
							mode_flag=0;
						}
						if(mode1>1)
						{
							if(jiajian_flag==1)
							{ 
								jia++;
								switch(mode1)
								{
									case(2): if(Velocity_Kp<620)
									         { 
														 PPP+=5;
													 }
										       Velocity_Kp = PPP; break;
									case(3): III+=20;Balance_Ki = III; break;
									case(4): if(Balance_Kd<3.4) 
									         {
														 DDD+=0.05;
													 }
										       Balance_Kd = DDD; break;
									default: break;
								}
								jiajian_flag=0;
							}
							if(jiajian_flag==2)
							{ 
								jian++;				
								switch(mode1)
								{
									case(2):if(Velocity_Kp>340)
									         { 
														 PPP-=40;
													 } Velocity_Kp = PPP; break;
									case(3): III-=20;Balance_Ki = III; break;
									case(4): if(Balance_Kd>2.01) 
									         {
														 DDD-=0.05;
													 }Balance_Kd = DDD; break;
									default: break;
								}
								jiajian_flag=0;
							}
					  }
					}
				
				  /*****************���ݽ���*******************/
					else if((delay_count>50)&&(delay_count<100))
					{ 
						
						NRF24L01_RX_Mode();
						delay_us(1000);
						SetRX_Mode();
						delay_us(1000);
						SPI_Read_Buf(RD_RX_PLOAD,RxBuf,TX_PLOAD_WIDTH);
						sta=SPI_Read(STATUS);
						SPI_RW_Reg(NRF24L01_WRITE_REG+STATUS,0xff);
						if((RxBuf[0]==0x55)&&(RxBuf[1]==0x01))
						{
							printf("�����˵�һ����\r\n");
							go_flag=1;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						//�ж��Ƿ�Ϊ����ָ��
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x02))
						{
							printf("�����˵ڶ�����\r\n");
							go_flag=2;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x03))
						{
							printf("�����˵�������\r\n");
							go_flag=3;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x04))
						{
							printf("�����˵��ĸ���\r\n");
							go_flag=4;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x05))
						{
							printf("�����˵������\r\n");
//							init_flag =1;
							mode_flag=1;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x06))
						{
							printf("�����˵�������\r\n");
							jiajian_flag = 1;
//							king_flag=1;  //�շ�ģʽ��ֻ��ģʽ�л���־λ
							delay_ms(10);
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x07))
						{
							printf("�����˵��߸���\r\n");
							jiajian_flag = 2;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x08))
						{
							printf("�����˵ڰ˸���\r\n");
							init_flag =1;
//							mode_flag=1;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}
						else  if((RxBuf[0]==0x55)&&(RxBuf[1]==0x09))
						{
							printf("�����˵ھŸ���\r\n");
							king_flag =1;
//							mode_flag=1;
							RxBuf[0]=0;  RxBuf[1]=0; 
						}

					}
					else if(delay_count>100)
					{
					 delay_count = 0;
					}
       }	
/********************ֻ��ģʽ*******************************/			 
		   else if(king_flag==1)
			 {
				 SPI_RW_Reg(NRF24L01_WRITE_REG+STATUS,0xff);
					jiaodu = (int)(roll_two*100);
					jiaodu1 = (jiaodu >>24)&0x000000ff;jiaodu2 = (jiaodu>>16)&0x000000ff;jiaodu3 = (jiaodu>>8)&0x000000ff;jiaodu4 = (jiaodu)&0x000000ff;
					TxBuf[0]=jiaodu1; TxBuf[1]=jiaodu2;TxBuf[2]=jiaodu3;TxBuf[3]=jiaodu4;

					Motor_Right1 = (Motor_Right >>24)&0x000000ff;Motor_Right2 = (Motor_Right>>16)&0x000000ff;Motor_Right3 = (Motor_Right>>8)&0x000000ff;Motor_Right4 = (Motor_Right)&0x000000ff;
					TxBuf[4]=Motor_Right1; TxBuf[5]=Motor_Right2;TxBuf[6]=Motor_Right3;TxBuf[7]=Motor_Right4;

					Velocity_Left_real= (int)(Velocity_Left*100);
					Velocity_Left1 = (Velocity_Left_real >>24)&0x000000ff;Velocity_Left2 = (Velocity_Left_real>>16)&0x000000ff;Velocity_Left3 = (Velocity_Left_real>>8)&0x000000ff;Velocity_Left4 = (Velocity_Left_real)&0x000000ff;
					TxBuf[8]=Velocity_Left1; TxBuf[9]=Velocity_Left2;TxBuf[10]=Velocity_Left3;TxBuf[11]=Velocity_Left4;
          
				  Balance_Kp_real= (int)(Velocity_Kp*100);
					Balance_Kp1 = (Balance_Kp_real >>24)&0x000000ff;Balance_Kp2 = (Balance_Kp_real>>16)&0x000000ff;Balance_Kp3 = (Balance_Kp_real>>8)&0x000000ff;Balance_Kp4 = (Balance_Kp_real)&0x000000ff;
					TxBuf[12]=Balance_Kp1; TxBuf[13]=Balance_Kp2;TxBuf[14]=Balance_Kp3;TxBuf[15]=Balance_Kp4;
					
					Balance_Ki_real= (int)(Balance_Ki);
					Balance_Ki1 = (Balance_Ki_real >>8)&0x000000ff;Balance_Ki2 = (Balance_Ki_real)&0x000000ff;
					TxBuf[16]=Balance_Ki1; TxBuf[17]=Balance_Ki2;
					
					Balance_Kd_real= (int)(Balance_Kd*100);
					Balance_Kd1 = (Balance_Kd_real >>8)&0x000000ff;Balance_Kd2 = (Balance_Kd_real)&0x000000ff;
					TxBuf[18]=Balance_Kd1; TxBuf[19]=Balance_Kd2;
					
					TxBuf[20]=mode1;
					
					NRF24L01_TX_Mode();
					delay_us(1000);
					nRF24L01_TxPacket(TxBuf);
					sta=SPI_Read(STATUS);
			 }
		}				 		  
	}
