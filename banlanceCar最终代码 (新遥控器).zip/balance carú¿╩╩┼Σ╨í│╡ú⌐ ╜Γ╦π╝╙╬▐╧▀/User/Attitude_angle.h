#ifndef __ATTITUDE_ANGLE_H
#define	__ATTITUDE_ANGLE_H

#include "stm32f10x.h"

//#define  PI  3.14
//DSP��
#include <math.h>

void  angle_calculation(void);
void  AHRS_IMU(short gyro[],short accel[]);
void data_fusion(void);
void MPU6050_huoqu(void);
#endif

