#ifndef _USART_H
#define _USART_H

#include "stm32f10x.h"
#include "stdio.h"

#define BYTE0(dwTemp) (*(char *)(&dwTemp))//ȡ����0-7λ
#define BYTE1(dwTemp) (*((char *)(&dwTemp)+1))//ȡ����8-15λ
#define BYTE2(dwTemp) (*((char *)(&dwTemp)+2))//ȡ����16-23λ
#define BYTE3(dwTemp) (*((char *)(&dwTemp)+3))//ȡ����24-32λ

void USART_Config(void);
void ANOTCV6_Data32_10(int32_t Data[],int32_t Kalman[],int32_t FIR[],int32_t Aver[]);
void ange_usart_sendbyte(USART_TypeDef *USARTx,u8 x);
#endif
