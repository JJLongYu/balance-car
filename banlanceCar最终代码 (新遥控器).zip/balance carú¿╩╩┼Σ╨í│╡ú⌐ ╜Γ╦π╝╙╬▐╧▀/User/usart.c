/***************************************************************************************
									声明
本项目代码仅供个人学习使用，可以自由移植修改，但必须保留此声明信息。移植过程中出现其他不可
估量的BUG，修远智控不负任何责任。请勿商用！

程序版本号：	2.0
日期：			2017-1-1
作者：			东方萧雨
版权所有：		修远智控N0.1实验室
****************************************************************************************/
/************************************************************************
USART传输数据或者打印数据
移植时，只需修改下面代码修改区中的代码即可

测试代码为：
	USART_Config();
	printf("vvvv");
*************************************************************************/
#include "usart.h"


/***********************************************************************
移植代码修改区
************************************************************************/
#define USE_USART1					//若使用的不是USART1，则把这句注释掉即可
#define USART						USART1
#define RCC_PORT				RCC_APB2Periph_GPIOA
#define RCC_USART				RCC_APB2Periph_USART1
#define PORT						GPIOA
#define TX							GPIO_Pin_9
#define RX							GPIO_Pin_10
/************************************************************************/



/******************************函数区************************************/
void USART_Config(void)
{
	GPIO_InitTypeDef GPIO_initStructure;
	USART_InitTypeDef USART_initStructure;
	
	RCC_APB2PeriphClockCmd(RCC_PORT,ENABLE);
	
	#ifdef USE_USART1
		RCC_APB2PeriphClockCmd(RCC_USART,ENABLE);
	#else
		RCC_APB1PeriphClockCmd(RCC_USART,ENABLE);
	#endif
	
	//作为USART的TX端和RX端的引脚初始化
	GPIO_initStructure.GPIO_Pin = TX;
	GPIO_initStructure.GPIO_Mode = GPIO_Mode_AF_PP;			//复用推挽输出
	GPIO_initStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(PORT,&GPIO_initStructure);
	
	GPIO_initStructure.GPIO_Pin = RX;
	GPIO_initStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;	//浮空输入
	GPIO_Init(PORT,&GPIO_initStructure);
	
	//配置USART
	USART_initStructure.USART_BaudRate = 115200;
	USART_initStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_initStructure.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
	USART_initStructure.USART_Parity = USART_Parity_No;
	USART_initStructure.USART_StopBits = USART_StopBits_1;
	USART_initStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART,&USART_initStructure);
	
	USART_Cmd(USART,ENABLE);
	
}	


/*********************************************************************
作用：发送一种数据类型给V6版本匿名上位机，32位12条曲线
参数：data[],XYZ轴原始数据 Kalman[]XYZ轴卡尔曼数据 FIR[]XYZ轴FIR数据 AverXYZ轴平均滤波数据
********************************************************************/
void ANOTCV6_Data32_10(int32_t Data[],int32_t Kalman[],int32_t FIR[],int32_t Aver[])
{
	uint8_t sum=0,i;
	uint8_t buf[48]={0};
	for(i=0;i<48;i=i+16)
	{
		buf[i]  =BYTE3(Data[i/16]);
		buf[i+1]=BYTE2(Data[i/16]);//原始数据
		buf[i+2]=BYTE1(Data[i/16]);
		buf[i+3]=BYTE0(Data[i/16]);//原始数据		
		
		buf[i+4]=BYTE3(Kalman[i/16]);
		buf[i+5]=BYTE2(Kalman[i/16]);//卡尔曼滤波
		buf[i+6]=BYTE1(Kalman[i/16]);
		buf[i+7]=BYTE0(Kalman[i/16]);//卡尔曼滤波		
		
		
		buf[i+8] =BYTE3(FIR[i/16]);
		buf[i+9] =BYTE2(FIR[i/16]);//FIR滤波
		buf[i+10]=BYTE1(FIR[i/16]);
		buf[i+11]=BYTE0(FIR[i/16]);//FIR滤波	
		
		buf[i+12]=BYTE3(Aver[i/16]);
		buf[i+13]=BYTE2(Aver[i/16]);//平均滤波
		buf[i+14]=BYTE1(Aver[i/16]);
		buf[i+15]=BYTE0(Aver[i/16]);//平均滤波	
	}	

	sum=sum+0xAA+0x05+0XAF+0XF1+48;
	
	USART_SendData(USART,0xAA);
	while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);
	USART_SendData(USART,0x05);
	while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);
	USART_SendData(USART,0XAF);
	while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);	
	USART_SendData(USART,0XF1);
	while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);	
	USART_SendData(USART,48);
	while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);	

	for(i=0;i<48;i++)
	{
		USART_SendData(USART,buf[i]);
		while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);
		sum=sum+buf[i];
	}
	USART_SendData(USART,sum);
	while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);
}

//内部调用函数，注意要勾选OPTIONS中的USE Micro LIB选项
int fputc(int ch,FILE *f)
{
	USART_SendData(USART,(u8)ch);
	while(USART_GetFlagStatus(USART,USART_FLAG_TXE)==RESET);
	return ch;
}
void ange_usart_sendbyte(USART_TypeDef *USARTx,u8 x)
{
	USART_SendData(USARTx,x);
	while(USART_GetFlagStatus(USARTx,USART_FLAG_TXE)==0); //等待发送完毕
//USART_FLAG_CTS CTS 标志位
//USART_FLAG_LBD LIN 中断检测标志位
//USART_FLAG_TXE 发送数据寄存器空标志位
//USART_FLAG_TC 发送完成标志位
//USART_FLAG_RXNE 接收数据寄存器非空标志位
//USART_FLAG_IDLE 空闲总线标志位
//USART_FLAG_ORE 溢出错误标志位
//USART_FLAG_NE 噪声错误标志位
//USART_FLAG_FE 帧错误标志位
//USART_FLAG_PE 奇偶错误标志位
}


