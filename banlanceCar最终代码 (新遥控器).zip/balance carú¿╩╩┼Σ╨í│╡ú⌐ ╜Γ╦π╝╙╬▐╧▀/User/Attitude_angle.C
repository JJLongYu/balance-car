#include "Attitude_angle.h"
#include "KALMAN_ERJIE.h"
#include "mpu6050_i2cmoni.h"
#include "math.h"
#include "usart.h"

short   gyro_two[3];							//ԭʼ����
short  accel_two[3];      				//ԭʼ����
int qq;
/*
*��ȡ���ٶ��Լ����ٶ�ֵ
*
*/

void MPU6050_huoqu()
{
	accel_two[0]=MPU6050_MoniI2c_GetAccX();
	accel_two[1]=MPU6050_MoniI2c_GetAccY();	
	accel_two[2]=MPU6050_MoniI2c_GetAccZ();
	
	gyro_two[0]=MPU6050_MoniI2c_GetGyroX();
	qq = gyro_two[0];
	gyro_two[1]=MPU6050_MoniI2c_GetGyroY();
	gyro_two[2]=MPU6050_MoniI2c_GetGyroZ();	
	
	
//	printf("accel_two[0]:%d",accel_two[0]);	
//	printf("accel_two[1]:%d",accel_two[1]);
//	printf("accel_two[2]:%d",accel_two[2]);
//	printf("gyro_two[0]:%d",gyro_two[0]);
//	printf("gyro_two[1]:%d",gyro_two[1]);
//	printf("gyro_two[2]:%d \r\n",gyro_two[2]);	
} 


/*
*���ã�������̬��
*
*

*/


double roll_two=0.0,pitch_two=0.0;
double roll_gyro_two,  pitch_gyro_two;
double roll_accel_two, pitch_accel_two;
double KP,KI;			//����ϵ��

double T;  //�Խ��ٶȽ��л��ֵ�ʱ�䣬���ֵΪ�ɼ�Ƶ�ʵĵ���

double gyro_two_updata[3];



void  angle_calculation()
{
////�ɼ��ٶȵõ��ĽǶ�
	roll_accel_two	=  atan2((double)accel_two[1],(double)accel_two[2])*180/PI;
	pitch_accel_two = -atan2((double)(accel_two[0]),sqrt((double)accel_two[1]*accel_two[1]+accel_two[2]*accel_two[2]))*180/PI;

	gyro_two[0]=gyro_two[0]/16.384;
	gyro_two[1]=gyro_two[1]/16.384;	
	gyro_two[2]=gyro_two[2]/16.384;
	
	roll_gyro_two  = roll_gyro_two + gyro_two[0]*T;
	pitch_gyro_two = roll_gyro_two + gyro_two[1]*T;
#if 0	
	KP=1.0;
	KI=1.0;
	T=0.005;  //200HZ����Ƶ��	
	
	gyro_two[0]=gyro_two[0]-gyro_two_pz[0];
	gyro_two[1]=gyro_two[1]-gyro_two_pz[1];
	gyro_two[2]=gyro_two[2]-gyro_two_pz[2];	
	
	gyro_two[0]=gyro_two[0]/16.384;
	gyro_two[1]=gyro_two[1]/16.384;	
	gyro_two[2]=gyro_two[2]/16.384;
			
//��ԭ���õ��ǶȵĻ����ϣ����ý��ٶ������һ��ʱ�̵ĽǶȡ������½��ٶȣ�
//			gyro_two_updata[0] = (double)gyro_two[0] + ((sin(pitch_two)*sin(roll_two))/cos(pitch_two))*(double)gyro_two[1] + ((cos(roll_two)*sin(pitch_two))/cos(pitch_two))*(double)gyro_two[2];
//			roll_gyro_two  = roll_two + gyro_two_updata[0]*T;
//			gyro_two_updata[1] = cos(roll_two)*(double)gyro_two[1] - sin(roll_two)*(double)gyro_two[2];
//			pitch_gyro_two = pitch_two + gyro_two_updata[1]*T;
			
			roll_gyro_two  = roll_two + gyro_two[0]*T;
			pitch_gyro_two = pitch_two + gyro_two[1]*T;
		
////�õ����յĽǶ�
			if((gyro_two[0]<10)&&(gyro_two[0]>(-10)))
			{
				roll_two  = KP*roll_gyro_two  + (1-KP)*roll_accel_two;
				pitch_two = KP*pitch_gyro_two + (1-KP)*pitch_accel_two;
			}
			else
			{
				roll_two  = KI*roll_gyro_two  + (1-KI)*roll_accel_two;
				pitch_two = KI*pitch_gyro_two + (1-KI)*pitch_accel_two;				
			}	

#endif
			
#if  1
				Kalman_filter_x(roll_accel_two,gyro_two[0],0.000001,0.01,0.005,0.00089);
				roll_two=KalmanData2[0];
				roll_two=-roll_two;
#endif			
			
//			printf("pitch:%lf",roll_two);
			
}



