#ifndef _FILTER_H_
#define _FILTER_H_

#include "stm32f10x.h"


float Kalman_Filter_x(float Accel,float Gyro);
double KalmanFilter1(const double ResrcData,double ProcessNiose_Q,double MeasureNoise_R,double InitialPrediction);

#endif
