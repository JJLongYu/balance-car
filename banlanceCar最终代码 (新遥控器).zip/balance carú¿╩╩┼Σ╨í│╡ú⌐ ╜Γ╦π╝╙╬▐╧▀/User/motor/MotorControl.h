#ifndef _MOTORCONTROL_H
#define _MOTORCONTROL_H

#include "stm32f10x.h"

#define TB6612_AIN1  GPIO_Pin_5  //PB5
#define TB6612_AIN2  GPIO_Pin_15   //PA15
 
#define TB6612_BIN1  GPIO_Pin_4  //PB4
#define TB6612_BIN2  GPIO_Pin_12  //PA12 

#define ange_TIMtx TIM1
#define ange_TIMt_APBxClock RCC_APB2PeriphClockCmd
#define ange_TIMt_CLK       RCC_APB2Periph_TIM1
#define ange_TIMt_IRQ       TIM1_IRQn
#define ange_TIMt_IRQHandler  TIM1_IRQHandler
#define ange_TIMt_Prescaler   72-1
#define ange_TIMt_Period      1000-1
//////
#define ange_TIMt_PWM1_Pulse  800-1
//#define ange_TIMt_PWM2_Pulse  4
//#define ange_TIMt_PWM3_Pulse  4
#define ange_TIMt_PWM4_Pulse  20-1
//////
///tim1 ch1
#define ange_TIMt_CH1_CLK RCC_APB2Periph_GPIOA
#define ange_TIMt_CH1_PORT GPIOA
#define ange_TIMt_CH1_Pin  GPIO_Pin_8

///tim1 ch4
#define ange_TIMt_CH4_CLK RCC_APB2Periph_GPIOA
#define ange_TIMt_CH4_PORT GPIOA
#define ange_TIMt_CH4_Pin  GPIO_Pin_11

#define ange_TIMjx TIM6
#define ange_TIMj_APBxClock RCC_APB1PeriphClockCmd
#define ange_TIMj_CLK       RCC_APB1Periph_TIM6
#define ange_TIMj_IRQ       TIM6_IRQn
#define ange_TIMj_IRQHandler  TIM6_IRQHandler

void ange_TIMt_PWM_init(void);
void MOTOR_GPIO_Config(void);
void dianjioutput(int Voltage);
void ange_TIMj_init(void);
void Balance_PWM_Init(u16 arr, u16 psc);		//��ʼ��PWM����͵�����ƶ�
#endif
