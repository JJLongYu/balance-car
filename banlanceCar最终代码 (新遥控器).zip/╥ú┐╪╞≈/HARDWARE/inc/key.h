#ifndef __KEY_H
#define __KEY_H
#include "stm32f10x.h"

#define KEY1  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)//��ȡ����0������/ֹͣ
#define KEY2  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)//��ȡ����1������
#define KEY3 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)
#define KEY4  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)
#define KEY5  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)
#define KEY6  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)
#define KEY7  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)
#define KEY8  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)
#define KEY9  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10)

//#define LED(a)  if(a) GPIO_ResetBits(GPIOC, GPIO_Pin_13);\
//				else  GPIO_SetBits(GPIOC, GPIO_Pin_13);
void KEY_Init(void);


#endif 


