#ifndef __LED_H
#define __LED_H
#define LED1(a)  if(a) GPIO_SetBits(GPIOB, GPIO_Pin_3);\
				else  GPIO_ResetBits(GPIOB, GPIO_Pin_3);
#define LED2(a)  if(a) GPIO_SetBits(GPIOA, GPIO_Pin_15);\
				else  GPIO_ResetBits(GPIOA, GPIO_Pin_15);
#define LED3(a)  if(a) GPIO_SetBits(GPIOA, GPIO_Pin_12);\
				else  GPIO_ResetBits(GPIOA, GPIO_Pin_12);
#define LED4(a)  if(a) GPIO_SetBits(GPIOA,GPIO_Pin_11);\
				else  GPIO_ResetBits(GPIOA, GPIO_Pin_11);
#define LED5(a)  if(a) GPIO_SetBits(GPIOB,GPIO_Pin_12);\
				else  GPIO_ResetBits(GPIOB, GPIO_Pin_12);
void LED_Init(void);       //LED��ʼ��

#endif

