#ifndef _TIMEJ_H_
#define _TIMEJ_H_


#include "stm32f10x.h"


#define            BASIC_TIM                   TIM2
#define            BASIC_TIM_APBxClock_FUN     RCC_APB1PeriphClockCmd
#define            BASIC_TIM_CLK               RCC_APB1Periph_TIM2
#define            BASIC_TIM_Period            (10000-1)
#define            BASIC_TIM_Prescaler         7199
#define            BASIC_TIM_IRQ               TIM6_IRQn
#define            BASIC_TIM_IRQHandler        TIM6_IRQHandler


void BASIC_TIM_Init(void);

#endif
