#include "led.h"
#include "stm32f10x.h"
#include "delay.h"
#include "2401.h"
#include "key.h"
#include "oled.h"	 
#include "timej.h"
#include "usart.h"
extern u8 TxBuf[21]; 
extern u8 RxBuf[21];
extern u8 OLED_GRAM[128][8];
u8 X=0;
u8 jiaoduzhengfu;
char jiaodu1,jiaodu2,jiaodu3,jiaodu4;
int jiaodu;
float jiaodu_xianshi;
char Motor_Right1,Motor_Right2,Motor_Right3,Motor_Right4;
int Motor_Right;
int Velocity_Left_real;
char Velocity_Left1,Velocity_Left2,Velocity_Left3,Velocity_Left4;
float Velocity_Left_real2;
int shijian;
int Balance_Kp;
u8 Balance_Kp1,Balance_Kp2,Balance_Kp3,Balance_Kp4;
int Balance_Ki;
u8 Balance_Ki1,Balance_Ki2;
int Balance_Kd;
u8 Balance_Kd1,Balance_Kd2;
float Balance_Kd_float;
u8 mode = 1;
u8 king_flag;
int fasong1[2],fasong2[2],fasong3[2],fasong4[2];
int main()
{
	u8 lock_key=0;
	u8 sta;
	u8 d=0;
	//u8 i;
	u8 pit[]={"pit:"};
	u8 PWM[]={"PWM:"};
	u8 MotorSpeed[]={"MotorSpeed:"};
	u8 PP[] = {"P:"};
	u8 II[] = {"I:"};
	u8 DD[] = {"D:"};
	u8 nodata[] = {"No Data"};
	LED_Init();
	KEY_Init();
	delay_init();
	
	uart_init(115200);
	BASIC_TIM_Init();
//	
//	delay_ms(1000);
	NRF24L01_GPIO_Init();
	delay_us(1000);
	NRF2401_CE_LOW;
	NRF2401_CSN_HIGH;     //IO������
	NRF2401_SCK_LOW;
	delay_us(1000);
	
	GPIO_OLED_InitConfig();   //��ʼ����ʾ��
	OLED_Clear();             //��������,������,������Ļ�Ǻ�ɫ��!��û����һ��
	OLED_ShowString(0,0,nodata,8,1);
	OLED_Refresh_Gram();	 //ˢ��OLED��Ļ
	NRF24L01_RX_Mode();
	LED1(1);LED2(1);LED3(1);LED4(1);LED5(0);
	while(1)
	{ 
/********************�շ�ģʽ*******************************/
		if(king_flag==0)
		{
			shijian = TIM_GetCounter(BASIC_TIM);
    /*****************���ݽ���*******************/
		if(shijian<1000)
		{ 
			SPI_RW_Reg(NRF24L01_WRITE_REG+STATUS,0xff);
			NRF24L01_RX_Mode();
			sta=SPI_Read(STATUS);
			if(1)
			{
				SPI_Read_Buf(RD_RX_PLOAD,RxBuf,TX_PLOAD_WIDTH);
				jiaodu1=RxBuf[0];jiaodu2=RxBuf[1];jiaodu3=RxBuf[2];jiaodu4=RxBuf[3];
				jiaodu = ((int)jiaodu1<<24)|((int)jiaodu2<<16)|((int)jiaodu3<<8)|jiaodu4;
				
				Motor_Right1=RxBuf[4];Motor_Right2=RxBuf[5];Motor_Right3=RxBuf[6];Motor_Right4=RxBuf[7];
				Motor_Right = ((int)Motor_Right1<<24)|((int)Motor_Right2<<16)|((int)Motor_Right3<<8)|Motor_Right4;

				Velocity_Left1=RxBuf[8];Velocity_Left2=RxBuf[9];Velocity_Left3=RxBuf[10];Velocity_Left4=RxBuf[11];
				Velocity_Left_real = ((int)Velocity_Left1<<24)|((int)Velocity_Left2<<16)|((int)Velocity_Left3<<8)|Velocity_Left4;
			
				Balance_Kp1=RxBuf[12];Balance_Kp2=RxBuf[13];Balance_Kp3=RxBuf[14];Balance_Kp4=RxBuf[15];
				Balance_Kp = (((int)Balance_Kp1<<24)|((int)Balance_Kp2<<16)|((int)Balance_Kp3<<8)|Balance_Kp4)/100;
				
				Balance_Ki1=RxBuf[16];Balance_Ki2=RxBuf[17];
				Balance_Ki = ((int)Balance_Ki1<<8)|((int)Balance_Ki2);
				
				Balance_Kd1=RxBuf[18];Balance_Kd2=RxBuf[19];
				Balance_Kd = ((int)Balance_Kd1<<8)|((int)Balance_Kd2);
				
				mode = RxBuf[20];
			}
			else ;;
			jiaodu_xianshi = (float)jiaodu/100;
			Velocity_Left_real2 = (float)Velocity_Left_real/100;
			Balance_Kd_float = (float)Balance_Kd/100;
//			printf("�Ƕȣ�%d  %x\r\n",Balance_Kd,Balance_Kd);
//			printf("jiaodu1��%x jiaodu2��%x jiaodu3��%x jiaodu4��%x \r\n",Balance_Kd1,Balance_Kd2,Balance_Kp3,Balance_Kp4);
//			printf("PWM��%d  %x\r\n",Motor_Right,Motor_Right);
//			printf("Motor_Right1��%x Motor_Right2��%x Motor_Right3��%x Motor_Right4��%x \r\n",Motor_Right1,Motor_Right2,Motor_Right3,Motor_Right4);
			if(mode==1)
			{ 
				memset(OLED_GRAM, 0, sizeof OLED_GRAM);
				OLED_ShowString(0,0,pit,8,1);
				OLED_ShowString(0,16,PWM,8,1);
				OLED_ShowString(0,32,MotorSpeed,8,1);
				OLED_ShowFloat(30,0,jiaodu_xianshi,4,8,1);
				OLED_ShowNum(30,16,Motor_Right,4,8,1);
				OLED_ShowFloat(68,32,Velocity_Left_real2,4,8,1);
				OLED_Refresh_Gram();	 //ˢ��OLED��Ļ
			}
			else if(mode>1)
			{
				memset(OLED_GRAM, 0, sizeof OLED_GRAM);
				OLED_ShowString(10,0,PP,8,1);
				OLED_ShowString(10,16,II,8,1);
				OLED_ShowString(10,32,DD,8,1);
				OLED_ShowNum(30,0,Balance_Kp,4,8,1);
				OLED_ShowNum(30,16,Balance_Ki,4,8,1);
				OLED_ShowFloat(30,32,Balance_Kd_float,4,8,1);
				switch (mode)
				{
					case(2):OLED_ShowChar(0,0,'*',8,1);OLED_ShowChar(0,16,' ',8,1);OLED_ShowChar(0,32,' ',8,1);break;
					case(3):OLED_ShowChar(0,0,' ',8,1);OLED_ShowChar(0,16,'*',8,1);OLED_ShowChar(0,32,' ',8,1);break;
					case(4):OLED_ShowChar(0,0,' ',8,1);OLED_ShowChar(0,16,' ',8,1);OLED_ShowChar(0,32,'*',8,1);break;
					default:break;
				}
				OLED_Refresh_Gram();	 //ˢ��OLED��Ļ
			}
	  }
		/*****************���ݷ���***********3********/
		else if((shijian>1000)&&(shijian<2000))
		{  
				SPI_RW_Reg(NRF24L01_WRITE_REG+STATUS,0xff);
				if(KEY1 == 1)
				{ 
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x01;
					NRF2401_IQR_HIGH;
					NRF24L01_TX_Mode();
					LED1(0);LED2(1);LED3(1);LED4(1);LED5(1);
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					lock_key=1;
				}
				else if(KEY2 ==1)
				{
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x02;
					NRF2401_IQR_HIGH;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					LED1(1);LED2(1);LED3(1);LED4(0);LED5(1);
					lock_key=1;
				}		
				else if(KEY3 ==1)
				{
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x03;
					NRF2401_IQR_HIGH;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					LED1(1);LED2(1);LED3(0);LED4(1);LED5(1);
					lock_key=1;
				}	
				else if(KEY4 ==1)
				{
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x04;
					NRF2401_IQR_HIGH;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					LED1(1);LED2(0);LED3(1);LED4(1);LED5(1);
					lock_key=1;
				}	
				 if(KEY5 ==1)
				 {
					 d=1;
				 }
				 if((KEY5 ==0)&&(d==1))      //ѡ��
				{ 
					d=0;
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x05;
					NRF2401_IQR_HIGH;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					TxBuf[0] = 0x00;
					TxBuf[1] = 0x00;
//					LED1(0);LED2(0);LED3(0);LED4(0);
					lock_key=1;
				}
				 if(KEY6 ==1)
				 {
					 d=2;
				 }
				
				 if((KEY6 ==0)&&(d==2))     //
				{ 
					d=0;
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x06;
					NRF2401_IQR_HIGH;
//					king_flag=1;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					delay_ms(20);
					TxBuf[0] = 0x00;
					TxBuf[1] = 0x00;
					lock_key=1;
				}	
				 if(KEY7 ==1)
				 {
					 d=3;
				 }
				 if((KEY7 ==0)&&(d==3))
				{ 
					d=0;
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x07;
					NRF2401_IQR_HIGH;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					TxBuf[0] = 0x00;
					TxBuf[1] = 0x00;
					lock_key=1;
				}
				if(KEY8 ==1)
				 {
					 d=4;
				 }
				 if((KEY8 ==0)&&(d==4))
				{ 
					d=0;
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x08;
					NRF2401_IQR_HIGH;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					TxBuf[0] = 0x00;
					TxBuf[1] = 0x00;
					lock_key=1;
					LED1(1);LED2(1);LED3(1);LED4(1);LED5(0);
				}
				if(KEY9 ==1)
				 {
					 d=5;
				 }
				 if((KEY9 ==0)&&(d==5))
				{ 
					d=0;
					TxBuf[0] = 0x55;
					TxBuf[1] = 0x09;
					NRF2401_IQR_HIGH;
					SPI_RW_Reg(NRF24L01_WRITE_REG + STATUS,0xff);  //���TX_DS��MAX_RT�жϱ�־
					NRF24L01_TX_Mode();
					TxBuf[0] = 0x00;
					TxBuf[1] = 0x00;
					lock_key=1;
					king_flag=1;
				}
				sta=SPI_Read(STATUS);
			}	
			else if(shijian>2000)
			{
				TIM_SetCounter(BASIC_TIM,0);
			}
		}
/********************ֻ��ģʽ*******************************/	 
		else if(king_flag==1)
		{
			SPI_RW_Reg(NRF24L01_WRITE_REG+STATUS,0xff);
			NRF24L01_RX_Mode();
			sta=SPI_Read(STATUS);
			if(1)
			{
				SPI_Read_Buf(RD_RX_PLOAD,RxBuf,TX_PLOAD_WIDTH);
				jiaodu1=RxBuf[0];jiaodu2=RxBuf[1];jiaodu3=RxBuf[2];jiaodu4=RxBuf[3];
				jiaodu = ((int)jiaodu1<<24)|((int)jiaodu2<<16)|((int)jiaodu3<<8)|jiaodu4;
				
				Motor_Right1=RxBuf[4];Motor_Right2=RxBuf[5];Motor_Right3=RxBuf[6];Motor_Right4=RxBuf[7];
				Motor_Right = ((int)Motor_Right1<<24)|((int)Motor_Right2<<16)|((int)Motor_Right3<<8)|Motor_Right4;

				Velocity_Left1=RxBuf[8];Velocity_Left2=RxBuf[9];Velocity_Left3=RxBuf[10];Velocity_Left4=RxBuf[11];
				Velocity_Left_real = ((int)Velocity_Left1<<24)|((int)Velocity_Left2<<16)|((int)Velocity_Left3<<8)|Velocity_Left4;
			
				Balance_Kp1=RxBuf[12];Balance_Kp2=RxBuf[13];Balance_Kp3=RxBuf[14];Balance_Kp4=RxBuf[15];
				Balance_Kp = (((int)Balance_Kp1<<24)|((int)Balance_Kp2<<16)|((int)Balance_Kp3<<8)|Balance_Kp4)/100;
				
				Balance_Ki1=RxBuf[16];Balance_Ki2=RxBuf[17];
				Balance_Ki = ((int)Balance_Ki1<<8)|((int)Balance_Ki2);
				
				Balance_Kd1=RxBuf[18];Balance_Kd2=RxBuf[19];
				Balance_Kd = ((int)Balance_Kd1<<8)|((int)Balance_Kd2);
				
				mode = RxBuf[20];
			}
			else ;;
			jiaodu_xianshi = (float)jiaodu/100;
			Velocity_Left_real2 = (float)Velocity_Left_real/100;
			Balance_Kd_float = (float)Balance_Kd/100;
			fasong1[0]=jiaodu;
			fasong2[0]=-Motor_Right;
			fasong3[0]=-Velocity_Left_real/5;
			ANOTCV6_Data32_10(fasong1,fasong2,fasong3,fasong4);
		}
	}
}
